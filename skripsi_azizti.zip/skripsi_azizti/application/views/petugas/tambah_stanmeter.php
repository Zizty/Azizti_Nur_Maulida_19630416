  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <?= $this->session->flashdata('pesan_notifikasi'); ?>
      </section>
      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title">Tambah <?= $judul; ?></h3>
              </div>
              <div class="card-body col-md-6">
                  <form id="formTambah" action="" method="post" enctype="multipart/form-data">
                      <div class="modal-body">
                          <div class="form-group">
                              <label>Tanggal</label>
                              <div class="input-group date" id="reservationdate1" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" name="tanggal" data-target="#reservationdate1" value="<?= date('d-m-Y', strtotime(date('Y-m-d'))); ?>" data-toggle="datetimepicker">
                                  <div class="input-group-append" data-target="#reservationdate1" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                  </div>
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="id_pelanggan">Pilih Pelanggan</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_pelanggan" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php
                                    foreach ($pelanggan as $list) :
                                        $stanmeter = $this->db->order_by('indeks_sekarang', 'desc')->get_where('stanmeter', ['id_pelanggan' => $list['id_pelanggan']]);
                                        if ($stanmeter->num_rows() > 0) {
                                            $stanmeter = $stanmeter->row_array();
                                            $indeks_bulanlalu = $stanmeter['indeks_sekarang'];
                                        } else {
                                            $indeks_bulanlalu = '0';
                                        }
                                    ?>
                                      <option value="<?= $list['id_pelanggan']; ?>"><?= $list['no_pelanggan'] . '-' . $list['nama_pelanggan'] . ' (Indeks Bulan Lalu : ' . pisahribuan($indeks_bulanlalu) . ')'; ?></option>
                                  <?php endforeach; ?>
                              </select>
                              <small class="text-danger"><?= form_error('id_pelanggan'); ?></small>
                          </div>
                          <!--<div class="form-group">
                              <label for="indeks_sebelum">Indesk Meter Bulan Lalu</label>
                              <input type="number" name="indeks_sebelum" class="form-control" id="indeks_sebelum" value="" placeholder="Isi Indesk Meter Bulan Lalu">
                              <small class="text-danger"><?= form_error('indeks_sebelum'); ?></small>
                          </div>-->
                          <div class="form-group">
                              <label for="indeks_sebelum">Indesk Meter Bulan Lalu</label>
                              <input type="number" name="indeks_sebelum" class="form-control" id="indeks_sebelum" value="" placeholder="Isi Indesk Meter Bulan Lalu">
                              <small class="text-danger"><?= form_error('indeks_sebelum'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="indeks_sekarang">Indesk Meter Bulan Ini</label>
                              <input type="number" name="indeks_sekarang" class="form-control" id="indeks_sekarang" value="" placeholder="Isi Indesk Meter Bulan Ini">
                              <small class="text-danger"><?= form_error('indeks_sekarang'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_pegawai">Pilih Petugas</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_pegawai" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php
                                    foreach ($petugas as $list) :
                                        if ($list['id_pegawai'] !== '1') {
                                    ?>
                                          <option value="<?= $list['id_pegawai']; ?>"><?= $list['nama_pegawai']; ?></option>
                                  <?php }
                                    endforeach; ?>
                              </select>
                              <small class="text-danger"><?= form_error('id_pegawai'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="keterangan">Keterangan</label>
                              <input type="text" name="keterangan" class="form-control" id="keterangan" value="" placeholder="Isi keterangan">
                              <small class="text-danger"><?= form_error('keterangan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="file">Unggah Foto Stan Meter (format : gif|jpg|jpeg|png)</label>
                              <input type="file" class="form-control" id="file" name="file" required>
                              <small class="text-danger"><?= form_error('file'); ?></small>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-warning" onclick="window.location='<?= base_url('petugas/stanmeter'); ?>'"><i class="fa fa-arrow-left"></i> Kembali</button>
                          <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin ingin menambah data');"><i class="fa fa-save"></i> Simpan</button>
                      </div>
                  </form>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->