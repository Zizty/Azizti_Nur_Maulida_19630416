  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <!-- NOTIF FLASH DISINI-->
          <?php if ($this->session->flashdata()) : ?>
              <!-- right column -->
              <div class="col-md-12">
                  <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h5><i class="icon fas fa-check"></i> Notifkasi!</h5>
                      Data berhasil <?= $this->session->flashdata('flashdata'); ?>
                  </div>
              </div>
              <!--/.col (right) -->
          <?php endif; ?>
      </section>

      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title"><?= $judul; ?></h3>
              </div>
              <div class="card-body">
                  <div class="row mb-3">
                      <a href="<?= base_url('register/tambah_stanmeter') ?>"><button type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</button></a>
                  </div>
                  <table id="example1" class="table table-bordered table-striped">
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Tanggal</th>
                              <th>No Pelanggan</th>
                              <th>Nama Pelanggan</th>
                              <th>Indesk Sebelum</th>
                              <th>Indesk Sekarang</th>
                              <th>Pemakaian m<sup>3</sup></th>
                              <th>Total Biaya</th>
                              <th>Tanggal Tagihan</th>
                              <th>Status</th>
                              <th>Aksi</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php
                            $no = 1;
                            $beban = 0;
                            foreach ($stanmeter as $filter) :
                                $pelanggan = $this->Pelanggan_model->getpelangganById($filter['id_pelanggan']);
                                $golongan = $this->Golongan_model->getgolonganById($pelanggan['id_golongan']);
                                $petugas = $this->Pegawai_model->getPegawaiById($filter['id_pegawai']);

                                $beban = $golongan['beban'];
                                $selisih = $filter['indeks_sekarang'] - $filter['indeks_sebelum'];
                                if ($selisih < 501) {
                                    $kubik = 0.5;
                                    $total = $kubik * $beban;
                                } else {
                                    $hasilkubik = $selisih / 1000; //1,9
                                    $koma = ".";
                                    $tidakadakoma = strpos($hasilkubik, $koma);
                                    if ($tidakadakoma == false) {
                                        $kubik = $hasilkubik;
                                        $total = $hasilkubik * $beban;
                                    } else {
                                        $nilaibelakangkoma = substr($hasilkubik, strpos($hasilkubik, ".") + 1);
                                        $nilaibelakangkoma = '0.' . $nilaibelakangkoma;
                                        if ($nilaibelakangkoma < 0.5) {
                                            $kubik = strtok($hasilkubik, '.') . '.5';
                                            $total = $kubik * $beban;
                                        } else {
                                            $kubik = strtok($hasilkubik, '.') + 1;
                                            $total = $kubik * $beban;
                                        }
                                    }
                                }
                            ?>
                              <tr>
                                  <td><?= $no; ?></td>
                                  <td><?= tanggal_indo($filter['tanggal']); ?></td>
                                  <td><?= $pelanggan['no_pelanggan']; ?></td>
                                  <td><?= $pelanggan['nama_pelanggan']; ?></td>
                                  <td><?= pisahribuan($filter['indeks_sebelum']); ?></td>
                                  <td><?= pisahribuan($filter['indeks_sekarang']); ?></td>
                                  <td><?= $kubik; ?> m<sup>3</sup></td>
                                  <td><?= rupiah($total); ?></td>
                                  <td><?= tanggal_indo($filter['tanggal_tagihan']); ?></td>
                                  <td><?= status_tagihan($filter['id_status']); ?></td>
                                  <td>
                                      <a href="<?= base_url(); ?>register/detail_stanmeter/<?= $filter['id_stanmeter']; ?>"><button type="button" class="btn btn-success btn-sm"><i class="fa fa-info"></i> Detail</button></a>
                                      <a href="<?= base_url(); ?>register/ubah_stanmeter/<?= $filter['id_stanmeter']; ?>"><button type="button" class="btn btn-primary btn-sm"><i class=" fa fa-edit"></i> Ubah</button></a>
                                      <a href="<?= base_url(); ?>register/hapus_stanmeter/<?= $filter['id_stanmeter']; ?>"><button type="button" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data ini');"><i class="fa fa-trash"></i> Hapus</button></a>
                                  </td>
                              </tr>
                          <?php $no++;
                            endforeach; ?>
                      </tbody>
                      <tfoot>
                          <tr>
                              <th>No</th>
                              <th>Tanggal</th>
                              <th>No Pelanggan</th>
                              <th>Nama Pelanggan</th>
                              <th>Indesk Sebelum</th>
                              <th>Indesk Sekarang</th>
                              <th>Pemakaianm<sup>3</sup></th>
                              <th>Total Biaya</th>
                              <th>Tanggal Tagihan</th>
                              <th>Status</th>
                              <th>Aksi</th>
                          </tr>
                      </tfoot>
                  </table>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->