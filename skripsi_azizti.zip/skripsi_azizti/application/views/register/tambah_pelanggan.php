  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <?= $this->session->flashdata('pesan_notifikasi'); ?>
      </section>
      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title">Tambah <?= $judul; ?></h3>
              </div>
              <div class="card-body col-md-6">
                  <form id="formTambah" action="" method="post" enctype="multipart/form-data">
                      <div class="modal-body">
                          <div class="form-group">
                              <label>Tanggal</label>
                              <div class="input-group date" id="reservationdate1" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" name="tanggal" data-target="#reservationdate1" value="<?= date('d-m-Y', strtotime(date('Y-m-d'))); ?>" data-toggle="datetimepicker">
                                  <div class="input-group-append" data-target="#reservationdate1" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                  </div>
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="no_stanmeter">Nomor Stan Meter</label>
                              <input type="text" name="no_stanmeter" class="form-control" id="no_stanmeter" value="" placeholder="Isi Nomor Stan Meter">
                              <small class="text-danger"><?= form_error('no_stanmeter'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_golongan">Pilih Golongan</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_golongan" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php
                                    foreach ($golongan as $list) :
                                    ?>
                                      <option value="<?= $list['id_golongan']; ?>"><?= $list['nama_golongan']; ?></option>
                                  <?php endforeach; ?>
                              </select>
                              <small class="text-danger"><?= form_error('id_golongan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="nik">NIK</label>
                              <input type="text" name="nik" class="form-control" id="nik" value="" placeholder="Isi NIK">
                              <small class="text-danger"><?= form_error('nik'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="nama_pelanggan">Nama Pelanggan</label>
                              <input type="text" name="nama_pelanggan" class="form-control" id="nama_pelanggan" value="" placeholder="Isi Nama Pelanggan">
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="alamat">Alamat</label>
                              <input type="text" name="alamat" class="form-control" id="alamat" value="" placeholder="Isi Alamat">
                              <small class="text-danger"><?= form_error('alamat'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_kecamatan">Pilih Kecamatan</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_kecamatan" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php
                                    foreach ($kecamatan as $list) :
                                    ?>
                                      <option value="<?= $list['id_kecamatan']; ?>"><?= $list['nama_kecamatan']; ?></option>
                                  <?php endforeach; ?>
                              </select>
                              <small class="text-danger"><?= form_error('id_kecamatan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="nohp">Nomor HP</label>
                              <input type="text" name="nohp" class="form-control" id="nohp" value="" placeholder="Isi Nomor HP">
                              <small class="text-danger"><?= form_error('nohp'); ?></small>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-warning" onclick="window.location='<?= base_url('register/pelanggan'); ?>'"><i class="fa fa-arrow-left"></i> Kembali</button>
                          <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin ingin menambah data');"><i class="fa fa-save"></i> Simpan</button>
                      </div>
                  </form>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->