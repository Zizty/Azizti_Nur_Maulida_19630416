  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <?= $this->session->flashdata('pesan_notifikasi'); ?>
      </section>
      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title">Ubah <?= $judul; ?></h3>
              </div>
              <div class="card-body col-md-6">
                  <form id="formTambah" action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="id_pelanggan" class="form-control" id="id_pelanggan" value="<?= $pelanggan['id_pelanggan']; ?>">
                      <div class="modal-body">
                          <div class="form-group">
                              <label for="no_stanmeter">Nomor Stan Meter</label>
                              <input type="text" name="no_stanmeter" class="form-control" id="no_stanmeter" value="<?= $pelanggan['no_stanmeter']; ?>" placeholder="Isi Nomor Stan Meter">
                              <small class="text-danger"><?= form_error('id_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="no_pelanggan">Nomor Pelanggan</label>
                              <input type="text" name="no_pelanggan" class="form-control" id="no_pelanggan" value="<?= $pelanggan['no_pelanggan']; ?>" placeholder="Isi Nomor Pelanggan" readonly>
                              <small class="text-danger"><?= form_error('no_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_golongan">Pilih Golongan</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_golongan" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php foreach ($golongan as $list) :; ?>
                                      <?php
                                        if ($list['id_golongan'] == $pelanggan['id_golongan']) {

                                        ?>
                                          <option value="<?= $list['id_golongan']; ?>" selected="selected"><?= $list['nama_golongan']; ?></option>
                                      <?php
                                        } else {
                                        ?>
                                          <option value="<?= $list['id_golongan']; ?>"><?= $list['nama_golongan']; ?></option>
                                      <?php
                                        }
                                        ?>
                                  <?php endforeach; ?>
                              </select>
                          </div>
                          <div class="form-group">
                              <label for="nik">NIK</label>
                              <input type="text" name="nik" class="form-control" id="nik" value="<?= $pelanggan['nik']; ?>" placeholder="Isi NIK pelanggan">
                              <small class="text-danger"><?= form_error('nik'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="nama_pelanggan">Nama Pelanggan</label>
                              <input type="text" name="nama_pelanggan" class="form-control" id="nama_pelanggan" value="<?= $pelanggan['nama_pelanggan']; ?>" placeholder="Isi Nama Pelanggan">
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="alamat">Alamat</label>
                              <input type="text" name="alamat" class="form-control" id="alamat" value="<?= $pelanggan['alamat']; ?>" placeholder="Isi Alamat pelanggan">
                              <small class="text-danger"><?= form_error('alamat'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_kecamatan">Pilih Kecamatan</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_kecamatan" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php foreach ($kecamatan as $list) :; ?>
                                      <?php
                                        if ($list['id_kecamatan'] == $pelanggan['id_kecamatan']) {

                                        ?>
                                          <option value="<?= $list['id_kecamatan']; ?>" selected="selected"><?= $list['nama_kecamatan']; ?></option>
                                      <?php
                                        } else {
                                        ?>
                                          <option value="<?= $list['id_kecamatan']; ?>"><?= $list['nama_kecamatan']; ?></option>
                                      <?php
                                        }
                                        ?>
                                  <?php endforeach; ?>
                              </select>
                          </div>
                          <div class="form-group">
                              <label for="nohp">Nomor HP</label>
                              <input type="text" name="nohp" class="form-control" id="nohp" value="<?= $pelanggan['nohp']; ?>" placeholder="Isi No HP pelanggan">
                              <small class="text-danger"><?= form_error('nohp'); ?></small>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-warning" onclick="window.location='<?= base_url('register/stanmeter'); ?>'"><i class="fa fa-arrow-left"></i> Kembali</button>
                          <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin ingin menambah data');"><i class="fa fa-save"></i> Simpan</button>
                      </div>
                  </form>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->