  <!-- Main content -->
  <div class="invoice">
      <!-- title row -->
      <div class="row">
          <div class="col-12" align="center">
              <table width="80%" align="center">
                  <tr>
                      <td rowspan="2" align="right"><img src="<?= base_url('assets/dist/img/' . $profil['logo']); ?>" height="120" width="120" /></td>
                  </tr>
                  <tr>
                      <td align="center">
                          <h4><?= $profil['nama_profil']; ?></h4>
                          <p>Alamat : <?= $profil['alamat']; ?>. Telp :<?= $profil['telepon']; ?>. Kodepos : <?= $profil['kodepos']; ?> <br />
                              Email : <?= $profil['email']; ?>. Website : <?= $profil['website']; ?></p>
                          <h4>
                              Laporan <?= $judul; ?> 3 Tagihan
                          </h4>
                      </td>
                  </tr>
              </table>
          </div>
      </div>
      <hr />

      <!-- Table row -->
      <div class="row">
          <div class="col-12 table-responsive">
              <table class="table table-striped">
                  <thead>
                      <tr>
                          <th>No</th>
                          <th>No Pelanggan</th>
                          <th>Nama Pelanggan</th>
                          <th>Alamat</th>
                          <th>No HP</th>
                          <th>Golongan</th>
                          <th>Jumlah Tagihan</th>
                          <th>Denda</th>
                          <th>Tagihan</th>
                          <th>Total Tagihan</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php
                        $no = 1;
                        foreach ($filter as $fr) :
                            $golongan = $this->Golongan_model->getgolonganById($fr['id_golongan']);
                            $jumlahtunggakan = $this->db->get_where('stanmeter', [
                                'id_pelanggan' => $fr['id_pelanggan'],
                                'id_status' => '0'
                            ])->num_rows();
                            if ($jumlahtunggakan > 2) {
                                $tagihan = $this->db->get_where('stanmeter', [
                                    'id_pelanggan' => $fr['id_pelanggan'],
                                    'id_status' => '0'
                                ])->result_array();
                                $totaltagihan = 0;
                                foreach ($tagihan as $tagih) {
                                    $beban = $golongan['beban'];
                                    $selisih = $tagih['indeks_sekarang'] - $tagih['indeks_sebelum'];
                                    if ($selisih < 501) {
                                        $kubik = 0.5;
                                        $total = $kubik * $beban;
                                    } else {
                                        $hasilkubik = $selisih / 1000; //1,9
                                        $koma = ".";
                                        $tidakadakoma = strpos($hasilkubik, $koma);
                                        if ($tidakadakoma == false) {
                                            $kubik = $hasilkubik;
                                            $total = $hasilkubik * $beban;
                                        } else {
                                            $nilaibelakangkoma = substr($hasilkubik, strpos($hasilkubik, ".") + 1);
                                            $nilaibelakangkoma = '0.' . $nilaibelakangkoma;
                                            if ($nilaibelakangkoma < 0.5) {
                                                $kubik = strtok($hasilkubik, '.') . '.5';
                                                $total = $kubik * $beban;
                                            } else {
                                                $kubik = strtok($hasilkubik, '.') + 1;
                                                $total = $kubik * $beban;
                                            }
                                        }
                                    }
                                    $tgl1 = strtotime($tagih['tanggal_tagihan']);
                                    $tgl2 = strtotime(date('Y-m-d'));

                                    $jarak = $tgl2 - $tgl1;

                                    $lama = $jarak / 60 / 60 / 24;
                                    if ($lama <= 30) {
                                        $denda = 20000;
                                    } else {
                                        $lama = $lama / 30;
                                        $lama = floor($lama);
                                        $denda = $lama * 20000;
                                    }

                                    $totaltagihan = $totaltagihan + $total;
                                }

                        ?>
                              <tr>
                                  <td><?= $no; ?></td>
                                  <td><?= $fr['no_pelanggan']; ?></td>
                                  <td><?= $fr['nama_pelanggan']; ?></td>
                                  <td><?= $fr['alamat']; ?></td>
                                  <td><?= $fr['nohp']; ?></td>
                                  <td><?= $golongan['nama_golongan']; ?></td>
                                  <td><?= $jumlahtunggakan; ?></td>
                                  <td><?= rupiah($denda); ?></td>
                                  <td><?= rupiah($totaltagihan); ?></td>
                                  <td><?= rupiah($totaltagihan + $denda); ?></td>
                              </tr>
                      <?php
                                $no++;
                            }
                        endforeach;
                        ?>
                  </tbody>
              </table>
          </div>
          <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row">
          <!-- accepted payments column -->
          <div class="col-6">

          </div>
          <!-- /.col -->
          <div class="col-6">
              <?php
                $pejabatttd = $this->db->get_where('pejabat_ttd', [
                    'aktif' => '1'
                ])->row_array();
                $nip_pejabattd = $pejabatttd['nip'];
                $nama_pejabattd = $pejabatttd['nama_pegawai'];
                $id_jabatanttd = $pejabatttd['id_jabatan'];
                $jabatanttd = $this->db->get_where('jabatan', ['id_jabatan' => $id_jabatanttd])->row_array();
                $nama_jabatanttd = $jabatanttd['nama_jabatan'];
                ?>
              <table align="right" width="60%">
                  <tr align="center">
                      <td>Kandangan, <?= tanggal_indo(date('Y-m-d')); ?></td>
                  </tr>
                  <tr align="center">
                      <td><?= $nama_jabatanttd; ?><br /><br /><br /></td>
                  </tr>
                  <tr align="center">
                      <td><b><u><?= $nama_pejabattd ?></u></b></td>
                  </tr>
                  <tr align="center">
                      <td><b><?= 'NIP. ' . $nip_pejabattd ?></b></td>
                  </tr>
              </table>
          </div>
          <!-- /.col -->
      </div>
      <!-- /.row -->
  </div>