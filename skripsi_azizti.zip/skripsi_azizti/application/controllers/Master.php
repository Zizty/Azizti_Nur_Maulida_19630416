<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Master extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        $this->load->model('Profil_model');
        $this->load->model('Menu_model');
        $this->load->model('Submenu_model');
        $this->load->model('Level_model');
        $this->load->model('Aksesmenu_model');
        $this->load->model('Pengguna_model');
        $this->load->model('Jabatan_model');
        $this->load->model('Pegawai_model');

        $this->load->model('Golongan_model');
        $this->load->model('Kecamatan_model');


        $this->load->helper('string');

        check_login();
    }

    //MASTER INDEX
    public function index()
    {

        redirect(base_url());
    }
    //MENU
    public function menu()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastermenu'] = $this->Menu_model->getAllMenu();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/menu', $data);
        $this->load->view('templates/footer', $data);
    }
    public function tambah_menu()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastermenu'] = $this->Menu_model->getAllMenu();

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_menu', 'Nama Menu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'Icon', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_menu', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Menu_model->tambahDataMenu();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/menu');
        }
    }

    public function ubah_menu($id_menu)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastermenu'] = $this->Menu_model->getMenuById($id_menu);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_menu', 'Nama Menu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'Icon', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_menu', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Menu_model->ubahDataMenu();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/menu');
        }
    }

    public function hapus_menu($id_menu)
    {

        $this->Menu_model->hapusDataMenu($id_menu);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/menu');
    }

    public function detail_menu($id_menu)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastermenu'] = $this->Menu_model->getMenuById($id_menu);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_menu', $data);
        $this->load->view('templates/footer', $data);
    }

    // SUB MENU
    public function submenu()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Sub Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastersubmenu'] = $this->Submenu_model->getAllsubmenu();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/submenu', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_submenu()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Sub Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastersubmenu'] = $this->Submenu_model->getAllsubmenu();
        $data['mastermenu'] = $this->db->get('menu')->result_array();


        $this->form_validation->set_rules('id_menu', 'Menu', 'required');
        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_submenu', 'Nama Submenu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'Icon', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_submenu', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Submenu_model->tambahDataSubmenu();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/submenu');
        }
    }

    public function ubah_submenu($id_submenu)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Sub Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['mastersubmenu'] = $this->Submenu_model->getSubmenuById($id_submenu);
        $data['mastermenu'] = $this->db->get('menu')->result_array();

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_submenu', 'Nama Submenu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'Icon', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_submenu', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Submenu_model->ubahDataSubmenu();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/submenu');
        }
    }

    public function hapus_submenu($id_submenu)
    {

        $this->Submenu_model->hapusDataSubmenu($id_submenu);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/submenu');
    }

    public function detail_submenu($id_submenu)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Sub Menu';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['submenu'] = $this->Submenu_model->getSubmenuById($id_submenu);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_submenu', $data);
        $this->load->view('templates/footer', $data);
    }

    //LEVEL
    public function level()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Level';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['levelakses'] = $this->Level_model->getAllLevel();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/level', $data);
        $this->load->view('templates/footer', $data);
    }
    public function tambah_level()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Level';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['levelakses'] = $this->Level_model->getAllLevel();

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_level', 'Nama Level', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_level', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Level_model->tambahDataLevel();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/level');
        }
    }

    public function ubah_level($id_level)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Level';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['levelakses'] = $this->Level_model->getLevelById($id_level);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_level', 'Nama Level', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_level', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Level_model->ubahDataLevel();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/level');
        }
    }

    public function hapus_level($id_level)
    {

        $this->Level_model->hapusDataLevel($id_level);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/level');
    }

    public function detail_level($id_level)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Level';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['levelakses'] = $this->db->get_where('level', ['id_level' => $id_level])->row_array();

        $data['menu'] = $this->Menu_model->getAllMenu();

        $this->form_validation->set_rules('id_level', 'Id Level', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/detail_level', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Aksesmenu_model->SimpanAksesMenu();
            $this->session->set_flashdata('flashdata', 'diperbaharui');
            redirect('master/level');
        }
    }
    // PENGGUNA
    public function pengguna()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pengguna';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpengguna'] = $this->Pengguna_model->getAllPengguna();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/pengguna', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_pengguna()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pengguna';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpengguna'] = $this->Pengguna_model->getAllPengguna();
        $data['masterlevel'] = $this->db->get('level')->result_array();
        $data['masterpegawai'] = $this->db->get('pegawai')->result_array();


        $this->form_validation->set_rules('id_level', 'Level', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Pegawai', 'required');
        $this->form_validation->set_rules('nama_pengguna', 'Nama pengguna', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_pengguna', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pengguna_model->tambahDataPengguna();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/pengguna');
        }
    }

    public function ubah_pengguna($id_pengguna)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pengguna';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpengguna'] = $this->Pengguna_model->getPenggunaById($id_pengguna);
        $data['masterlevel'] = $this->db->get('level')->result_array();

        $this->form_validation->set_rules('id_level', 'Level', 'required');
        $this->form_validation->set_rules('nama_pengguna', 'Nama pengguna', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_pengguna', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pengguna_model->ubahDataPengguna();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/pengguna');
        }
    }

    public function hapus_pengguna($id_pengguna)
    {

        $this->Pengguna_model->hapusDataPengguna($id_pengguna);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/pengguna');
    }

    public function detail_pengguna($id_pengguna)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pengguna';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpengguna'] = $this->Pengguna_model->getPenggunaById($id_pengguna);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_pengguna', $data);
        $this->load->view('templates/footer', $data);
    }

    //JABATAN
    public function jabatan()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Jabatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterjabatan'] = $this->Jabatan_model->getAllJabatan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/jabatan', $data);
        $this->load->view('templates/footer', $data);
    }
    public function tambah_jabatan()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Jabatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterjabatan'] = $this->Jabatan_model->getAllJabatan();

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_jabatan', 'Nama Jabatan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_jabatan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Jabatan_model->tambahDataJabatan();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/jabatan');
        }
    }

    public function ubah_jabatan($id_jabatan)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Jabatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterjabatan'] = $this->Jabatan_model->getjabatanById($id_jabatan);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_jabatan', 'Nama Jabatan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_jabatan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Jabatan_model->ubahDataJabatan();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/jabatan');
        }
    }

    public function hapus_jabatan($id_jabatan)
    {

        $this->Jabatan_model->hapusDataJabatan($id_jabatan);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/jabatan');
    }

    public function detail_jabatan($id_jabatan)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Jabatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterjabatan'] = $this->Jabatan_model->getjabatanById($id_jabatan);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_jabatan', $data);
        $this->load->view('templates/footer', $data);
    }

    //PEGAWAI
    public function pegawai()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pegawai';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpegawai'] = $this->Pegawai_model->getAllPegawai();
        $data['masterjabatan'] = $this->db->get('jabatan')->result_array();
        $data['mastergolpangkat'] = $this->db->get('golpangkat')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/pegawai', $data);
        $this->load->view('templates/footer', $data);
    }
    public function tambah_pegawai()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Beranda';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpegawai'] = $this->Pegawai_model->getAllPegawai();
        $data['masterjabatan'] = $this->db->get('jabatan')->result_array();
        $data['mastergolpangkat'] = $this->db->get('golpangkat')->result_array();

        $this->form_validation->set_rules('nip', 'nip', 'required');
        $this->form_validation->set_rules('nama_pegawai', 'Nama Pegawai', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_pegawai', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pegawai_model->tambahDataPegawai();
            $this->session->set_flashdata('flashdata', 'ditambahkan');
            redirect('master/pegawai');
        }
    }

    public function ubah_pegawai($id_pegawai)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pegawai';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpegawai'] = $this->Pegawai_model->getPegawaiById($id_pegawai);
        $data['masterjabatan'] = $this->db->get('jabatan')->result_array();
        $data['mastergolpangkat'] = $this->db->get('golpangkat')->result_array();

        $this->form_validation->set_rules('nip', 'nip', 'required');
        $this->form_validation->set_rules('nama_pegawai', 'Nama Pegawai', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_pegawai', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pegawai_model->ubahDataPegawai();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/pegawai');
        }
    }

    public function hapus_pegawai($id_pegawai)
    {

        $this->Pegawai_model->hapusDataPegawai($id_pegawai);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/pegawai');
    }

    public function detail_pegawai($id_pegawai)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pegawai';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpegawai'] = $this->Pegawai_model->getPegawaiById($id_pegawai);
        $data['masterjabatan'] = $this->db->get('jabatan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_pegawai', $data);
        $this->load->view('templates/footer', $data);
    }
    //golongan
    public function golongan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Golongan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['golongan'] = $this->Golongan_model->getAllgolongan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/golongan', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_golongan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Golongan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_golongan', 'Nama Golongan', 'required');
        $this->form_validation->set_rules('beban', 'Beban', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_golongan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Golongan_model->tambahDatagolongan();
            $this->session->set_flashdata('flashdata', 'ditambah');
            redirect('master/golongan');
        }
    }

    public function ubah_golongan($id_golongan)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Golongan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['golongan'] = $this->Golongan_model->getgolonganById($id_golongan);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_golongan', 'Nama Golongan', 'required');
        $this->form_validation->set_rules('beban', 'Beban', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_golongan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Golongan_model->ubahDatagolongan();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/golongan');
        }
    }

    public function hapus_golongan($id_golongan)
    {

        $this->Golongan_model->hapusDatagolongan($id_golongan);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/golongan');
    }

    public function detail_golongan($id_golongan)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Golongan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['golongan'] = $this->Golongan_model->getgolonganById($id_golongan);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_golongan', $data);
        $this->load->view('templates/footer', $data);
    }
    //kecamatan
    public function kecamatan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getAllkecamatan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/kecamatan', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_kecamatan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_kecamatan', 'Nama kecamatan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/tambah_kecamatan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Kecamatan_model->tambahDatakecamatan();
            $this->session->set_flashdata('flashdata', 'ditambah');
            redirect('master/kecamatan');
        }
    }

    public function ubah_kecamatan($id_kecamatan)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getkecamatanById($id_kecamatan);

        $this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $this->form_validation->set_rules('nama_kecamatan', 'Nama kecamatan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('master/ubah_kecamatan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Kecamatan_model->ubahDatakecamatan();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('master/kecamatan');
        }
    }

    public function hapus_kecamatan($id_kecamatan)
    {

        $this->Kecamatan_model->hapusDatakecamatan($id_kecamatan);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('master/kecamatan');
    }

    public function detail_kecamatan($id_kecamatan)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getkecamatanById($id_kecamatan);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('master/detail_kecamatan', $data);
        $this->load->view('templates/footer', $data);
    }
}
