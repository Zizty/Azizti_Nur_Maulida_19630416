<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Register extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();

        $this->load->model('Profil_model');
        $this->load->model('Menu_model');
        $this->load->model('Submenu_model');
        $this->load->model('Level_model');
        $this->load->model('Aksesmenu_model');
        $this->load->model('Pengguna_model');
        $this->load->model('Jabatan_model');
        $this->load->model('Pegawai_model');

        $this->load->model('Golongan_model');
        $this->load->model('Kecamatan_model');
        $this->load->model('Pelanggan_model');
        $this->load->model('Stanmeter_model');
        $this->load->model('Pembayaran_model');
        $this->load->model('Stanmeterrusak_model');
        $this->load->model('Stanmeterganti_model');

        check_login();
        check_username();
        $this->load->helper('string');
    }

    //REGISTER INDEX
    public function index()
    {

        redirect(base_url());
    }

    //pelanggan
    public function pelanggan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getAllkecamatan();
        $data['pelanggan'] = $this->Pelanggan_model->getAllpelanggan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/pelanggan', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_pelanggan()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getAllkecamatan();
        $data['golongan'] = $this->Golongan_model->getAllgolongan();
        $data['pelanggan'] = $this->Pelanggan_model->getAllpelanggan();

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('no_stanmeter', 'Nomor Stan Meter', 'required');
        $this->form_validation->set_rules('id_golongan', 'Golongan', 'required');
        $this->form_validation->set_rules('nik', 'NIK', 'required');
        $this->form_validation->set_rules('nama_pelanggan', 'Nama Pelanggan', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('id_kecamatan', 'Kecamatan', 'required');
        $this->form_validation->set_rules('nohp', 'No HP', 'required');


        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/tambah_pelanggan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pelanggan_model->tambahDatapelanggan();
            $this->session->set_flashdata('flashdata', 'ditambah');
            redirect('register/pelanggan');
        }
    }

    public function ubah_pelanggan($id_pelanggan)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['kecamatan'] = $this->Kecamatan_model->getAllkecamatan();
        $data['golongan'] = $this->Golongan_model->getAllgolongan();
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($id_pelanggan);

        $this->form_validation->set_rules('id_pelanggan', 'pelanggan', 'required');
        $this->form_validation->set_rules('no_stanmeter', 'Nomor Stan Meter', 'required');
        $this->form_validation->set_rules('id_golongan', 'Golongan', 'required');
        $this->form_validation->set_rules('nik', 'NIK', 'required');
        $this->form_validation->set_rules('nama_pelanggan', 'Nama Pelanggan', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('id_kecamatan', 'Kecamatan', 'required');
        $this->form_validation->set_rules('nohp', 'No HP', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/ubah_pelanggan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pelanggan_model->ubahDatapelanggan($id_pelanggan);
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('register/pelanggan');
        }
    }

    public function hapus_pelanggan($id_pelanggan)
    {

        $this->Pelanggan_model->hapusDatapelanggan($id_pelanggan);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('register/pelanggan');
    }

    public function detail_pelanggan($id_pelanggan)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);


        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($id_pelanggan);
        $data['kecamatan'] = $this->Kecamatan_model->getkecamatanById($data['pelanggan']['id_kecamatan']);


        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/detail_pelanggan', $data);
        $this->load->view('templates/footer', $data);
    }
    //stanmeter
    public function stanmeter()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->Stanmeter_model->getAllstanmeter();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/stanmeter', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_stanmeter()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['pelanggan'] = $this->Pelanggan_model->getAllpelanggan();
        $data['stanmeter'] = $this->Stanmeter_model->getAllstanmeter();

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        //$this->form_validation->set_rules('indeks_sebelum', 'Indeks Meter Bulan Lalu', 'required');
        $this->form_validation->set_rules('indeks_sekarang', 'Indesk Meter Bulan Ini', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/tambah_stanmeter', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $uploadfile = $_FILES['file']['name'];
            $acak = random_string('alnum', 16);
            $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
            if ($uploadfile) {
                $config['file_name'] = $file_baru;
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = '10000';
                $config['upload_path'] = './files/';
            }

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('file')) {
                $this->Stanmeter_model->tambahDatastanmeter($file_baru);
                $this->session->set_flashdata('flashdata', 'ditambah');
                redirect('register/stanmeter');
            } else {
                $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload surat!</div>');
                echo "<script>history.go(-1);</script>";
            }
        }
    }

    public function ubah_stanmeter($id_stanmeter)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['stanmeter'] = $this->Stanmeter_model->getstanmeterById($id_stanmeter);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeter']['id_pelanggan']);

        $this->form_validation->set_rules('id_stanmeter', 'stanmeter', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        //$this->form_validation->set_rules('indeks_sebelum', 'Indeks Meter Bulan Lalu', 'required');
        $this->form_validation->set_rules('indeks_sekarang', 'Indesk Meter Bulan Ini', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/ubah_stanmeter', $data);
            $this->load->view('templates/footer', $data);
        } else {
            if (!empty($_FILES['file']['name'])) {
                $this->load->helper('string');
                $uploadfile = $_FILES['file']['name'];
                $acak = random_string('alnum', 16);
                $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
                if ($uploadfile) {
                    $config['file_name'] = $file_baru;
                    $config['allowed_types'] = 'gif|jpg|jpeg|png';
                    $config['max_size'] = '10000';
                    $config['upload_path'] = './files/';
                }

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('file')) {
                    $file_lama = $this->input->post('file_lama');
                    unlink(FCPATH . './files/' . $file_lama);
                    $this->Stanmeter_model->ubahDatastanmeterFile($file_baru);
                    $this->session->set_flashdata('flashdata', 'diubah');
                    redirect('register/stanmeter');
                } else {
                    $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload!</div>');
                    echo "<script>history.go(-1);</script>";
                }
            } else {

                $this->Stanmeter_model->ubahDatastanmeter();
                $this->session->set_flashdata('flashdata', 'diubah');
                redirect('register/stanmeter');
            }
        }
    }

    public function hapus_stanmeter($id_stanmeter)
    {
        $this->Pembayaran_model->hapusDatapembayaranByIdStan($id_stanmeter);
        $getId = $this->db->get_where('stanmeter', ['id_stanmeter' => $id_stanmeter])->row_array();
        $this->Stanmeter_model->hapusDatastanmeter($id_stanmeter);
        unlink(FCPATH . 'files/' . $getId['file']);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('register/stanmeter');
    }

    public function detail_stanmeter($id_stanmeter)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);


        $data['stanmeter'] = $this->Stanmeter_model->getstanmeterById($id_stanmeter);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeter']['id_pelanggan']);
        $data['golongan'] = $this->Golongan_model->getgolonganById($data['pelanggan']['id_golongan']);
        $data['petugas'] = $this->Pegawai_model->getPegawaiById($data['stanmeter']['id_pegawai']);


        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/detail_stanmeter', $data);
        $this->load->view('templates/footer', $data);
    }

    //tagihan
    public function tagihan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->Stanmeter_model->getAlltagihan();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/tagihan', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_tagihan($id_stanmeter)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->Stanmeter_model->getstanmeterById($id_stanmeter);

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_stanmeter', 'Stanmeter', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/tambah_tagihan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pembayaran_model->tambahDatapembayaran($id_stanmeter);
            $this->session->set_flashdata('flashdata', 'ditambah');
            redirect('register/tagihan');
        }
    }
    public function ubah_tagihan($id_pembayaran)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['pembayaran'] = $this->Pembayaran_model->getpembayaranById($id_pembayaran);
        $id_stanmeter = $data['pembayaran']['id_stanmeter'];
        $data['stanmeter'] = $this->Stanmeter_model->getstanmeterById($id_stanmeter);

        $this->form_validation->set_rules('id_pembayaran', 'Pembayaran', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_stanmeter', 'Stanmeter', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/ubah_tagihan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $this->Pembayaran_model->ubahDatapembayaran();
            $this->session->set_flashdata('flashdata', 'diubah');
            redirect('register/tagihan');
        }
    }

    //detail_tagihan
    public function detail_tagihan($id_stanmeter)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->Stanmeter_model->getstanmeterById($id_stanmeter);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeter']['id_pelanggan']);
        $data['golongan'] = $this->Golongan_model->getgolonganById($data['pelanggan']['id_golongan']);
        $data['petugas'] = $this->Pegawai_model->getPegawaiById($data['stanmeter']['id_pegawai']);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/detail_tagihan', $data);
        $this->load->view('templates/footer', $data);
    }



    //stanmeterrusak
    public function stanmeterrusak()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterrusak'] = $this->Stanmeterrusak_model->getAllstanmeterrusak();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/stanmeterrusak', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_stanmeterrusak()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['pelanggan'] = $this->Pelanggan_model->getAllpelanggan();
        $data['stanmeterrusak'] = $this->Stanmeterrusak_model->getAllstanmeterrusak();

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/tambah_stanmeterrusak', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $uploadfile = $_FILES['file']['name'];
            $acak = random_string('alnum', 16);
            $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
            if ($uploadfile) {
                $config['file_name'] = $file_baru;
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = '10000';
                $config['upload_path'] = './files/';
            }

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('file')) {
                $this->Stanmeterrusak_model->tambahDatastanmeterrusak($file_baru);
                $this->session->set_flashdata('flashdata', 'ditambah');
                redirect('register/stanmeterrusak');
            } else {
                $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload surat!</div>');
                echo "<script>history.go(-1);</script>";
            }
        }
    }

    public function ubah_stanmeterrusak($id_stanmeterrusak)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['stanmeterrusak'] = $this->Stanmeterrusak_model->getstanmeterrusakById($id_stanmeterrusak);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeterrusak']['id_pelanggan']);

        $this->form_validation->set_rules('id_stanmeterrusak', 'stanmeterrusak', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/ubah_stanmeterrusak', $data);
            $this->load->view('templates/footer', $data);
        } else {
            if (!empty($_FILES['file']['name'])) {
                $this->load->helper('string');
                $uploadfile = $_FILES['file']['name'];
                $acak = random_string('alnum', 16);
                $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
                if ($uploadfile) {
                    $config['file_name'] = $file_baru;
                    $config['allowed_types'] = 'gif|jpg|jpeg|png';
                    $config['max_size'] = '10000';
                    $config['upload_path'] = './files/';
                }

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('file')) {
                    $file_lama = $this->input->post('file_lama');
                    unlink(FCPATH . './files/' . $file_lama);
                    $this->Stanmeterrusak_model->ubahDatastanmeterrusakFile($file_baru);
                    $this->session->set_flashdata('flashdata', 'diubah');
                    redirect('register/stanmeterrusak');
                } else {
                    $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload!</div>');
                    echo "<script>history.go(-1);</script>";
                }
            } else {

                $this->Stanmeterrusak_model->ubahDatastanmeterrusak();
                $this->session->set_flashdata('flashdata', 'diubah');
                redirect('register/stanmeterrusak');
            }
        }
    }

    public function hapus_stanmeterrusak($id_stanmeterrusak)
    {
        $getId = $this->db->get_where('stanmeterrusak', ['id_stanmeterrusak' => $id_stanmeterrusak])->row_array();
        $this->Stanmeterrusak_model->hapusDatastanmeterrusak($id_stanmeterrusak);
        unlink(FCPATH . 'files/' . $getId['file']);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('register/stanmeterrusak');
    }

    public function detail_stanmeterrusak($id_stanmeterrusak)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterrusak'] = $this->Stanmeterrusak_model->getstanmeterrusakById($id_stanmeterrusak);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeterrusak']['id_pelanggan']);
        $data['golongan'] = $this->Golongan_model->getgolonganById($data['pelanggan']['id_golongan']);
        $data['petugas'] = $this->Pegawai_model->getPegawaiById($data['stanmeterrusak']['id_pegawai']);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/detail_stanmeterrusak', $data);
        $this->load->view('templates/footer', $data);
    }
    //stanmeterganti
    public function stanmeterganti()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterganti'] = $this->Stanmeterganti_model->getAllstanmeterganti();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/stanmeterganti', $data);
        $this->load->view('templates/footer', $data);
    }

    public function tambah_stanmeterganti()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['pelanggan'] = $this->Pelanggan_model->getAllpelanggan();
        $data['stanmeterganti'] = $this->Stanmeterganti_model->getAllstanmeterganti();

        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/tambah_stanmeterganti', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $uploadfile = $_FILES['file']['name'];
            $acak = random_string('alnum', 16);
            $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
            if ($uploadfile) {
                $config['file_name'] = $file_baru;
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $config['max_size'] = '10000';
                $config['upload_path'] = './files/';
            }

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('file')) {
                $this->Stanmeterganti_model->tambahDatastanmeterganti($file_baru);
                $this->session->set_flashdata('flashdata', 'ditambah');
                redirect('register/stanmeterganti');
            } else {
                $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload surat!</div>');
                echo "<script>history.go(-1);</script>";
            }
        }
    }

    public function ubah_stanmeterganti($id_stanmeterganti)
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['petugas'] = $this->db->get_where('pegawai', ['id_jabatan' => '6'])->result_array();
        $data['stanmeterganti'] = $this->Stanmeterganti_model->getstanmetergantiById($id_stanmeterganti);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeterganti']['id_pelanggan']);

        $this->form_validation->set_rules('id_stanmeterganti', 'stanmeterganti', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');
        $this->form_validation->set_rules('id_pelanggan', 'Pelanggan', 'required');
        $this->form_validation->set_rules('id_pegawai', 'Petugas', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('register/ubah_stanmeterganti', $data);
            $this->load->view('templates/footer', $data);
        } else {
            if (!empty($_FILES['file']['name'])) {
                $this->load->helper('string');
                $uploadfile = $_FILES['file']['name'];
                $acak = random_string('alnum', 16);
                $file_baru = $acak . "." . pathinfo($uploadfile, PATHINFO_EXTENSION);
                if ($uploadfile) {
                    $config['file_name'] = $file_baru;
                    $config['allowed_types'] = 'gif|jpg|jpeg|png';
                    $config['max_size'] = '10000';
                    $config['upload_path'] = './files/';
                }

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('file')) {
                    $file_lama = $this->input->post('file_lama');
                    unlink(FCPATH . './files/' . $file_lama);
                    $this->Stanmeterganti_model->ubahDatastanmetergantiFile($file_baru);
                    $this->session->set_flashdata('flashdata', 'diubah');
                    redirect('register/stanmeterganti');
                } else {
                    $this->session->set_flashdata('pesan_notifikasi', '<div class="alert alert-danger role="alert">Gagal melakukan upload!</div>');
                    echo "<script>history.go(-1);</script>";
                }
            } else {

                $this->Stanmeterganti_model->ubahDatastanmeterganti();
                $this->session->set_flashdata('flashdata', 'diubah');
                redirect('register/stanmeterganti');
            }
        }
    }

    public function hapus_stanmeterganti($id_stanmeterganti)
    {
        $getId = $this->db->get_where('stanmeterganti', ['id_stanmeterganti' => $id_stanmeterganti])->row_array();
        $this->Stanmeterganti_model->hapusDatastanmeterganti($id_stanmeterganti);
        unlink(FCPATH . 'files/' . $getId['file']);
        $this->session->set_flashdata('flashdata', 'dihapus');
        redirect('register/stanmeterganti');
    }

    public function detail_stanmeterganti($id_stanmeterganti)
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterganti'] = $this->Stanmeterganti_model->getstanmetergantiById($id_stanmeterganti);
        $data['pelanggan'] = $this->Pelanggan_model->getpelangganById($data['stanmeterganti']['id_pelanggan']);
        $data['golongan'] = $this->Golongan_model->getgolonganById($data['pelanggan']['id_golongan']);
        $data['petugas'] = $this->Pegawai_model->getPegawaiById($data['stanmeterganti']['id_pegawai']);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('register/detail_stanmeterganti', $data);
        $this->load->view('templates/footer', $data);
    }
}
