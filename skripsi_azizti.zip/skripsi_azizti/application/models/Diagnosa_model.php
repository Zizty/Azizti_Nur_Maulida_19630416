<?php

class diagnosa_model extends CI_Model
{

    public function getAlldiagnosa()
    {

        return $this->db->get('diagnosa')->result_array();
    }

    public function getdiagnosaById($id_diagnosa)
    {

        return $this->db->get_where('diagnosa', ['id_diagnosa' => $id_diagnosa])->row_array();
    }
    public function getdiagnosaByIdPenyakit($id_penyakit)
    {

        return $this->db->get_where('diagnosa', ['id_penyakit' => $id_penyakit])->result_array();
    }

    public function tambahDatadiagnosa()
    {

        $data = [
            "id_penyakit" => $this->input->post('id_penyakit', true),
            "kode" => $this->input->post('kode', true),
            "nama_diagnosa" => $this->input->post('nama_diagnosa', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('diagnosa', $data);
    }

    public function ubahDatadiagnosa()
    {

        $data = [
            "id_penyakit" => $this->input->post('id_penyakit', true),
            "kode" => $this->input->post('kode', true),
            "nama_diagnosa" => $this->input->post('nama_diagnosa', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_diagnosa', $this->input->post('id_diagnosa', true));
        $this->db->update('diagnosa', $data);
    }

    public function hapusDatadiagnosa($id_diagnosa)
    {

        //$this->db->where('id_diagnosa',$id_diagnosa);
        //$this->db->delete('diagnosa');
        $this->db->delete('diagnosa', ['id_diagnosa' => $id_diagnosa]);
    }
}
