<?php

class Stanmeterrusak_model extends CI_Model
{

    public function getAllstanmeterrusak()
    {

        return $this->db->get('stanmeterrusak')->result_array();
    }

    public function getstanmeterrusakById($id_stanmeterrusak)
    {

        return $this->db->get_where('stanmeterrusak', ['id_stanmeterrusak' => $id_stanmeterrusak])->row_array();
    }

    public function tambahDatastanmeterrusak($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('stanmeterrusak', $data);
    }
    public function ubahDatastanmeterrusak()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeterrusak', $this->input->post('id_stanmeterrusak', true));
        $this->db->update('stanmeterrusak', $data);
    }
    public function ubahDatastanmeterrusakFile($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeterrusak', $this->input->post('id_stanmeterrusak', true));
        $this->db->update('stanmeterrusak', $data);
    }
    public function hapusDatastanmeterrusak($id_stanmeterrusak)
    {
        $this->db->delete('stanmeterrusak', ['id_stanmeterrusak' => $id_stanmeterrusak]);
    }
}
